This is a Clone of the Amzrican Website Amazon.com

The main functionalities are present and three pages are working : 

- index.html which is the homepage of the project
- zamazor_buy.html which allows the user to add products in his cart (Accessible in "Ventes Flash" in the navbar)
- panier.html which allows the management of the cart and the saved items (Accessible in "Panier" in the navbar)

The project is responsive and can be used on a mobile phone. It also keeps the products in the basket even with a refresh of the page.

It should be updated in the next few months.
